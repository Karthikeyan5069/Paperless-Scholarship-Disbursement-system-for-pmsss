import React from 'react'

function contactPage() {
  return (
    <div>contactPage</div>
  )
}

export default contactPage