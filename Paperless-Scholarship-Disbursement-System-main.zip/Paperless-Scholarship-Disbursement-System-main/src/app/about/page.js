import React from 'react'

function aboutPage() {
  return (
    <div>aboutPage</div>
  )
}

export default aboutPage