import React from 'react'

function notificationPage() {
  return (
    <div>notificationPage</div>
  )
}

export default notificationPage