import React from "react";
import InputFeilds from "./InputFeild"

function DashboardMain() {
  return (
    <div className=" w-[62vw] bg-slate-300 items-center justify-center flex flex-col">
     
    </div>
  );
}

export default DashboardMain;