import React from 'react'

function InputFeild() {
  return (
    <div></div>
  )
}

export default InputFeild